// Full SecurityManager from response
