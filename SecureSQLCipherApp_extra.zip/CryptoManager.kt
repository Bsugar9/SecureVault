// Full CryptoManager from response
