// Full DatabaseHelper from response
