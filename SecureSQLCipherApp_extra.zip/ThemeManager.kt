// Full ThemeManager from response
